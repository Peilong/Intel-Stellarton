rev0001
	-initial FAB B image based on Fab A rev_0004 with pin changes made for Fab B.
rev0002
	-Change the start of Arria configuration from immeadiatly after all S0 power is stable to the start of PowerMode M1
	-Change value that is being driving on the CK505 straps FSLA, FSLB, FSLC from 3'b000 to 3'b010 to force a 83.33 mhz BCLK instead of 100Mhz.
	 Change is need because we switched to rev2 of CK505 on fab B which has different strap setting than the rev1 part.
	-Change FS3/FS4 straps to CK505 from 2'b11 to 2'b00 to enable spread spectrum and set SATA clk to 100MHz
	-changed logic for straping the CK505 FSLA, FSLB and FSLC pins.  Insead of forceing straps to 83.33 mhz sys control latches value on BSEL pins during
	 powermode M1 and drives the latched value to the CK505 on FSLA, FSLB and FSLC.
	-added fix for shutdown and restart issue where TNC does not shutdown or restart from Windows or Linux.  Fix and's SC_EXTRA_STRAP[7] and SC_RSTRDY_N
	 so that either can be used in powerdown sequence.  kbdrst_n (from sio chip) is blue-wired to SC_EXTRA_STRAP[7] on the board.  Added fix for issue
	 Arria does not always successfully reconfigure after a shutdown or restart.
	-added functionality to sc_extra_strap[6].  If switch is off board will boot without pausing in powermode M1.  If switch is off board will pause at 
	 powermode M1 during boot then require user to push the "spare" button to continue boot.
	-added synchronization logic on SC_NSTATUS and SC_CONF_DONE signal.  
	-Fixed issue with warm reset where sys control was not waiting for rstrdy_n from TNC after an external warm reset.  Also increased delays during warm reset
	in effort to fix issue with hang a post code 0x30 after reset but hang still happens with this image.
rev0003
	-change sc_smbus_fet_en so that is is driven high when cpu is powered on.  This is an active high signal
	previous versions had the polarity backward.
	-changed SC_FTDI_HDR_SMB_FET_EN so that it is driven high when cpu is powered on.  This is an active high signal
	previous versions had the polarity backward.
rev0004
	Note: This image is for B0 parts only
	-Removed logic for locking the HPLL on TNC A0 parts
	-Change power-up sequence for VNN and v1p05_s rail so that they both come-up at the same time, to avoid backdrive issue that TNC team
	 is seeing on the PWRMODE pins when v1p05_s comes-up before the VNN rail
	-changed SC_SMI_N to open drain and added a weak pull-up in the I/O
	-added logic to toggle sc_pwrok 10 times during power-up as per TNC designers reccomendation for fixing issue with
	TNC sometimes not booting.
rev0005
	-changed power_up_fsm to fix issue with sys control not transitioning CPU to S3 after cpu asserts rstrdy_n.
	-fixed issue with sys control not powering system back to S0 when in S3 and powerbutton is pushed.
	-changed reset fsm to ignore sc_rstrdy_n during transition to suspend S3 as CPU doesn't seem to assert this signal like the documentation suggests it should
	-fixed issue with hanging in power-mode M1 during transition from S0 to S3